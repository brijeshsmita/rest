/**
 * 
 */
package com.oracle.rest.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.oracle.rest.entity.Employee;
import com.oracle.rest.exception.EmployeeException;

/**
 * @author Smita B Kumar
 *
 */
public class EmployeeDao implements IEmployeeDao {
	List<Employee> list;
	private static final Map<String, Employee> empMap = new HashMap<String, Employee>();

	static {
		initEmps();
	}

	private static void initEmps() {
		Employee emp1 = new Employee("E01", "Smith", "Clerk");
		Employee emp2 = new Employee("E02", "Allen", "Salesman");
		Employee emp3 = new Employee("E03", "Jones", "Manager");

		empMap.put(emp1.getEmpNo(), emp1);
		empMap.put(emp2.getEmpNo(), emp2);
		empMap.put(emp3.getEmpNo(), emp3);
	}

	@Override
	public Employee getEmployee(String empNo) throws EmployeeException {
		Employee emp = empMap.get(empNo);
		if(emp==null) {
			throw new EmployeeException("Employee not found with empNo : "+empNo);
		}
		return emp;
	}

	@Override
	public Employee addEmployee(Employee emp) throws EmployeeException {
		System.out.println("Adding Employee in dao "+emp);
		empMap.put(emp.getEmpNo(), emp);
		return emp;
	}

	@Override
	public Employee updateEmployee(Employee emp) throws EmployeeException {
		System.out.println("Updating Employee in dao "+emp);
		Employee emp1 = empMap.get(emp.getEmpNo());
		if(emp1==null) {
			throw new EmployeeException("Employee not found while updating Employee!");
		}	else {	
		 emp1=empMap.put(emp.getEmpNo(), emp);
		}		
		return emp1;
	}

	@Override
	public Employee deleteEmployee(String empNo) throws EmployeeException {
		System.out.println("Deleting Employee in dao "+empNo);
		Employee emp = empMap.get(empNo);
		if(emp==null) {
			throw new EmployeeException("Employee not found  while Deleting Employee!");
		}	else {	
		 emp=empMap.remove(empNo);
		}
		return emp;
	}

	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		Collection<Employee> c = empMap.values();
		List<Employee> list = new ArrayList<Employee>();
		list.addAll(c);
		return list;
	}

}