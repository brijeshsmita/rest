/**
 * 
 */
package com.oracle.rest.dao;

import java.util.List;

import com.oracle.rest.entity.Employee;
import com.oracle.rest.exception.EmployeeException;

/**
 * @author Smita B Kumar
 *
 */
public interface IEmployeeDao {

	public Employee getEmployee(String empNo)throws EmployeeException;

	public Employee addEmployee(Employee emp) throws EmployeeException;

	public Employee updateEmployee(Employee emp) throws EmployeeException;

	public Employee deleteEmployee(String empNo) throws EmployeeException;

	public List<Employee> getAllEmployees() throws EmployeeException;

}
