/**
 * 
 */
package com.oracle.rest.service;

import java.util.List;

import com.oracle.rest.dao.EmployeeDao;
import com.oracle.rest.dao.IEmployeeDao;
import com.oracle.rest.entity.Employee;
import com.oracle.rest.exception.EmployeeException;

/**
 * @author Smita B Kumar
 *
 */
public class EmployeeService implements IEmployeeService {
	private IEmployeeDao employeeDao;
	public EmployeeService() {
		employeeDao=new EmployeeDao();
	}

	@Override
	public Employee getEmployee(String empNo) throws EmployeeException {
		return employeeDao.getEmployee(empNo);
	}

	@Override
	public Employee addEmployee(Employee emp) throws EmployeeException {
		return employeeDao.addEmployee(emp);
	}

	@Override
	public Employee updateEmployee(Employee emp) throws EmployeeException {
		return employeeDao.updateEmployee(emp);
	}

	@Override
	public Employee deleteEmployee(String empNo) throws EmployeeException {
		return employeeDao.deleteEmployee(empNo);
	}

	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		
		return employeeDao.getAllEmployees();
	}

}