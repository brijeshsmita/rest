package com.oracle.rest.exception;

/**
 * @author Smita B Kumar
 *
 */
public class EmployeeException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4162111954464445858L;

	public EmployeeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	

}
