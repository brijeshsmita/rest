/**
 * 
 */
package com.oracle.rest.controller;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.oracle.rest.entity.Employee;
import com.oracle.rest.service.EmployeeService;
import com.oracle.rest.service.IEmployeeService;

/**
 * @author trainingfunc
 *
 */
//step 1: @Path
//uri : http://localhost:8082/03Employee_CRUD_Exception_Maven/rest/employees
@Path("/employees")
public class EmployeeController {
	//prep work -> instatiate service object
	private IEmployeeService employeeService;
	public EmployeeController() {
		employeeService = new EmployeeService();
	}
	
	//get all employees
	//uri : http://localhost:8082/03Employee_CRUD_Exception_Maven/rest/employees
	@GET
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public List<Employee> getAllEmps(){
		return employeeService.getAllEmployees();
	}
	//get all employee by id
		//uri : http://localhost:8082/03Employee_CRUD_Exception_Maven/rest/employees/id
	@GET
	@Path("/{empId}")
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public Response getEmpById(@PathParam("empId") String empNo){
		Employee emp= employeeService.getEmployee(empNo);
		return Response.ok().entity(emp).build();
		
	}
	
	//uri : http://localhost:8082/03Employee_CRUD_Exception_Maven/rest/employees
	@POST
	@Produces({MediaType.APPLICATION_JSON})
	@Consumes({MediaType.APPLICATION_XML})
	public Employee addEmps(Employee emp){
		return employeeService.addEmployee(emp);
	}
	
	//uri : http://localhost:8082/03Employee_CRUD_Exception_Maven/rest/employees
	@PUT
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public Employee updateEmps(Employee emp){
		return employeeService.updateEmployee(emp);
	}
	
	@DELETE
	@Path("/{empNo}")
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public Employee delEmps(@PathParam("empNo")String empNo){
		return employeeService.deleteEmployee(empNo);
	}

}












